
public class AnalizadorLLC {
    ConvertidorBinDec CBD = new ConvertidorBinDec();  
    String [][] LibreriaS = new String [4][2];
    String [][] LibreriaU = new String [8][2];
    
    public AnalizadorLLC(){
        LibreriaS[0][0]="00";
        LibreriaS[1][0]="01";
        LibreriaS[2][0]="10";
        LibreriaS[3][0]="11";
        
        LibreriaS[0][1]="RR";
        LibreriaS[1][1]="REJ";
        LibreriaS[2][1]="RNR";
        LibreriaS[3][1]="SREJ";
        
        LibreriaU[0][0]="00001";
        LibreriaU[1][0]="11011";
        LibreriaU[2][0]="11000";
        LibreriaU[3][0]="11100";
        LibreriaU[4][0]="11110";
        LibreriaU[5][0]="00000";
        LibreriaU[6][0]="00010";
        LibreriaU[7][0]="00110";
        
        LibreriaU[0][1]="SNR";
        LibreriaU[1][1]="SNRME";
        LibreriaU[2][1]="SARM";
        LibreriaU[3][1]="SABM";
        LibreriaU[4][1]="SABME";
        LibreriaU[5][1]="UI";
        LibreriaU[6][1]="DISC";
        LibreriaU[7][1]="UA";
        
    }
    
    public char analizarTipo(String Cadena){
        if(Cadena.charAt(0) == '0')
            return 'I';
        if(Cadena.charAt(1) == '0')
            return 'S';
        if(Cadena.charAt(1) == '1')
            return 'U';
        return 0;
    }
    public int getINs(String Cadena){
        if(Cadena.length() == 8){
        String Ns="";   
            for(int x=1;x<=3;x++)
               Ns = Ns + Cadena.charAt(x);
        Ns = CBD.voltearCadena(Ns);
        return CBD.conversorBinarioDecimal(Ns);
        }
        else{
            String Ns="";   
            for(int x=1;x<=7;x++)
               Ns = Ns + Cadena.charAt(x);
            Ns = CBD.voltearCadena(Ns);
            return CBD.conversorBinarioDecimal(Ns);
        }
    }
    public int getINr(String Cadena){
        if(Cadena.length() == 8){
        String Nr="";   
            for(int x=5;x<=7;x++)
               Nr = Nr + Cadena.charAt(x);
        Nr = CBD.voltearCadena(Nr);
        return CBD.conversorBinarioDecimal(Nr);
        }
        else{
            String Nr="";   
            for(int x=9;x<=15;x++)
               Nr = Nr + Cadena.charAt(x);
            Nr = CBD.voltearCadena(Nr);
            return CBD.conversorBinarioDecimal(Nr);
        }
    }
    public String getCodigoU(String Cadena){
        String CodU="";   
            for(int x=2;x<=3;x++)
               CodU = CodU + Cadena.charAt(x);
            for(int x=5;x<=7;x++)
               CodU = CodU + Cadena.charAt(x);
        for(int z=0;z<8;z++)
            if(LibreriaU[z][0].equals(CodU))
                return LibreriaU[z][1];
        return "Desconocida";
    }
    public String getCodigoS(String Cadena){
        String CodS="";   
            for(int x=2;x<=3;x++)
               CodS = CodS + Cadena.charAt(x);
         for(int z=0;z<4;z++)
            if(LibreriaS[z][0].equals(CodS))
                return LibreriaS[z][1];
        return "Desconocido";
    }
    public int getNrS(String Cadena){
       if(Cadena.length() == 8){
        String Nr="";   
        for(int x=5;x<=7;x++)
               Nr = Nr + Cadena.charAt(x);
        Nr = CBD.voltearCadena(Nr);
        return CBD.conversorBinarioDecimal(Nr);
        }
        else{
            String Nr="";   
            for(int x=9;x<=15;x++)
               Nr = Nr + Cadena.charAt(x);
            Nr = CBD.voltearCadena(Nr);
            return CBD.conversorBinarioDecimal(Nr);
        }
    }
    
}
