public class BibliotecaP {
private int [] numero;
private String [] protocolo;

public BibliotecaP(){
    numero = new int[21];
    protocolo = new String[21];
    numero[0] = 2048;
    protocolo[0] = "IP";
    numero[1] = 512;
    protocolo[1] = "PUP";
    numero[2] = 2054;
    protocolo[2] = "ARP";
    numero[3] = 32821;
    protocolo[3] = "RARP";
    numero[4] = 33024;
    protocolo[4] = "802.1q";
    numero[5] = 34525;
    protocolo[5] = "IPv6";
    numero[6] = 34915;
    protocolo[6] = "PPPOE discovery";
    numero[7] = 34916;
    protocolo[7] = "PPPOE session";
    numero[8] = 1536;
    protocolo[8] = "XEROX NS IDP";
    numero[9] = 32776;
    protocolo[9] = "AT&T";
    numero[10] = 15;
    protocolo[10] = "Diganostics";
    numero[11] = 16;
    protocolo[11] = "Echo Protocol";
    numero[12] = 17;
    protocolo[12] = "Banyan Vines";
    numero[13] = 20;
    protocolo[13] = "DECnet";
    numero[14] = 21;
    protocolo[14] = "Chaosnet";
    numero[15] = 23;
    protocolo[15] = "IEEE 802.2";
    numero[16] = 24;
    protocolo[16] = "RARP";
    numero[17] = 29;
    protocolo[17] = "TokenVIEW-10";
    numero[18] = 31;
    protocolo[18] = "AppleTalk LAP";
    numero[19] = 33;
    protocolo[19] = "Cornell Boot Server";
    numero[20] = 34;
    protocolo[20] = "Novell NetWare IPX";
}
    public String getProtocolo(int longitud){
        int x;
        for(x=0;x<21;x++){
            if(numero[x] == longitud)
                break;
        }
        if(x<21)
            return protocolo[x];
        else
            return "protocolo desconocido";
    }

}
