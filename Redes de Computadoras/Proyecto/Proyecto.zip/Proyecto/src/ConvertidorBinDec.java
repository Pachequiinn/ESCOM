
import javax.swing.JOptionPane;


public class ConvertidorBinDec {
    private static final String Cero   = "0000";
    private static final String Uno    = "0001";
    private static final String Dos    = "0010";
    private static final String Tres   = "0011";
    private static final String Cuatro = "0100";
    private static final String Cinco  = "0101";
    private static final String Seis   = "0110";
    private static final String Siete  = "0111";
    private static final String Ocho   = "1000";
    private static final String Nueve  = "1001";
    private static final String A      = "1010";
    private static final String B      = "1011";
    private static final String C      = "1100";
    private static final String D      = "1101";
    private static final String E      = "1110";
    private static final String F      = "1111";
    private String [] ValorString = new String [16];
    private char [] Caracteres = new char[16];
    
    public ConvertidorBinDec(){
        ValorString[0]=Cero;
        ValorString[1]=Uno;
        ValorString[2]=Dos;
        ValorString[3]=Tres;
        ValorString[4]=Cuatro;
        ValorString[5]=Cinco;
        ValorString[6]=Seis;
        ValorString[7]=Siete;
        ValorString[8]=Ocho;
        ValorString[9]=Nueve;
        ValorString[10]=A;
        ValorString[11]=B;
        ValorString[12]=C;
        ValorString[13]=D;
        ValorString[14]=E;
        ValorString[15]=F;
        Caracteres[0]='0';
        Caracteres[1]='1';
        Caracteres[2]='2';
        Caracteres[3]='3';
        Caracteres[4]='4';
        Caracteres[5]='5';
        Caracteres[6]='6';
        Caracteres[7]='7';
        Caracteres[8]='8';
        Caracteres[9]='9';
        Caracteres[10]='A';
        Caracteres[11]='B';
        Caracteres[12]='C';
        Caracteres[13]='D';
        Caracteres[14]='E';
        Caracteres[15]='F';
    }
    
   
    public String convertirDecBin(String Primero){
        try{
            Primero.charAt(1);
        }catch(Exception e){Primero = "0" + Primero;};
        //System.out.println("\n"+Primero);
        String Binario="";
        char PP = Primero.charAt(0);
        char PS = Primero.charAt(1);
        for(int x=0;x<16;x++)
            if((PS == Caracteres[x]) || PS == (Caracteres[x]+32))
                Binario = Binario + voltearCadena(ValorString[x]);
        for(int x=0;x<16;x++)
            if((PP == Caracteres[x]) || PP == (Caracteres[x]+32))
                Binario = Binario + voltearCadena(ValorString[x]);
        return Binario;
    }
    
    public String voltearCadena(String normal){
        String invertida = "";
        for(int x=(normal.length()-1);x>=0;x--){
            invertida=invertida+normal.charAt(x);
        }
        return invertida;
    }
    
    public int conversorBinarioDecimal(String Binario){
        int decimal=0;
        int x,y;
        for(x=(Binario.length()-1),y=0;x>=0;x--,y++){
          decimal = decimal + ((Binario.charAt(x)-48)*(int)(Math.pow(2, y)));
        }
        return decimal;    
    }
}
